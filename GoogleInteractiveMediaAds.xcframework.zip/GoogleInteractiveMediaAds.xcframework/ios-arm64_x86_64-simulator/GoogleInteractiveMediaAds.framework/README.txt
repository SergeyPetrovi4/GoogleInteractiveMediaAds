========================================
Google Interactive Media Ads SDK for iOS
========================================

This is the Google Interactive Media Ads SDK for iOS.

Requirements:
- Xcode 6 or later.
- iOS deployment target of iOS 8.0 or later.

The latest documentation and code samples are available at:
https://developers.google.com/interactive-media-ads/
